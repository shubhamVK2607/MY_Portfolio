import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import "./About.scss";
import { images } from "../../constants";
import { AppWrap, MotionWrap } from "../../wrapper";
import { urlFor, client } from "../../client";

const About = () => {
  const [abouts, setAbouts] = useState([]);

  console.log("abouts length", abouts.length);

  useEffect(() => {
    const query = '*[_type == "abouts"]';

    client.fetch(query).then((data) => {
      setAbouts(data);
    });
  }, []);

  return (
    <>
      <h2 className="head-text-about">
        I am a <span>Frontend Web Developer</span>
        <br />
      </h2>
      <p className="p-text-about">
        I'm a React.js Developer. My goal is to build a fast, flexible,
        mobile-first website that clearly communicates with visitors. I have
        done my Btech in Computer Science and Engineering from Jaipur
        Engineering College and Research Center. I have total 2 years experience
        in the industrial field as a Frontend web developer. I have developed
        various screens for front end part of many multilingual products. Apart
        from this I Utilized React to build high-quality, scalable and reusable
        components and used React, React Hooks, Redux, React-Router for app routing.
      </p>

      <div className="app__profiles">
        {abouts.map((about, index) => (
          <motion.div
            whileInView={{ opacity: 1 }}
            whileHover={{ scale: 1.1 }}
            transition={{ duration: 0.5, type: "tween" }}
            className="app__profile-item"
            key={about.title + index}
          >
            <img src={urlFor(about.imgUrl)} alt="about.title" />
            <h2 className="bold-text" style={{ marginTop: "20px" }}>
              {about.title}
            </h2>
            <p className="p-text" style={{ marginTop: "10px" }}>
              {about.description}
            </p>
          </motion.div>
        ))}
      </div>
    </>
  );
};

export default AppWrap(
  MotionWrap(About, "app__about"),
  "about",
  "app__whitebg"
);
