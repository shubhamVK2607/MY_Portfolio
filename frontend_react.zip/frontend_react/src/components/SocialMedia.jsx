import React from 'react'
import {BsTwitter, BsInstagram} from 'react-icons/bs'
import {FaFacebookF} from 'react-icons/fa'
import { FaLinkedin } from 'react-icons/fa';
import { FaGithub } from 'react-icons/fa';



const SocialMedia = () => {
  return (
    <div className='app__social'>
        <div>
            <a href="https://www.linkedin.com/in/shubham-singh-14313618b" target="_blank"><FaLinkedin/></a>
        </div>
        <div>
           <a href="https://github.com/shubhamVK2607" target="_blank"><FaGithub/></a> 
        </div>
        <div>
            <a href="https://www.facebook.com/profile.php?id=100007999213825" target="_blank"><FaFacebookF/></a>
        </div>
      
    </div>
  )
}

export default SocialMedia
